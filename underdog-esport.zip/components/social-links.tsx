import type React from "react"
import { Facebook, Instagram, Twitch, Twitter, Youtube } from "lucide-react"
import Link from "next/link"

export function SocialLinks() {
  return (
    <div className="flex items-center justify-center space-x-4">
      <SocialIcon href="#" icon={<Twitter className="h-5 w-5" />} label="Twitter" />
      <SocialIcon href="#" icon={<Instagram className="h-5 w-5" />} label="Instagram" />
      <SocialIcon href="#" icon={<Twitch className="h-5 w-5" />} label="Twitch" />
      <SocialIcon href="#" icon={<Youtube className="h-5 w-5" />} label="YouTube" />
      <SocialIcon href="#" icon={<Facebook className="h-5 w-5" />} label="Facebook" />
    </div>
  )
}

interface SocialIconProps {
  href: string
  icon: React.ReactNode
  label: string
}

function SocialIcon({ href, icon, label }: SocialIconProps) {
  return (
    <Link
      href={href}
      className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-800 text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
      aria-label={label}
    >
      {icon}
    </Link>
  )
}

