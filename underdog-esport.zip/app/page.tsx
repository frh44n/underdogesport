import { Countdown } from "@/components/countdown"
import { SocialLinks } from "@/components/social-links"

export default function Home() {
  // Launch date - set to 30 days from now
  const launchDate = new Date()
  launchDate.setDate(launchDate.getDate() + 30)

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-black text-white">
      <div className="absolute inset-0 bg-[url('/bg-pattern.svg')] opacity-10"></div>
      <div className="container relative flex max-w-5xl flex-col items-center justify-center px-4 py-16 text-center">
        <div className="mb-6 inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
          Coming Soon
        </div>
        <h1 className="mb-6 text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
          <span className="text-primary">Underdog</span> E-sport
        </h1>
        <p className="mb-10 max-w-2xl text-xl text-muted-foreground">
          We're working hard to bring you the ultimate e-sports experience. Stay tuned for our launch!
        </p>

        <Countdown targetDate={launchDate} />

        <div className="mt-16">
          <h2 className="mb-4 text-lg font-semibold">Follow us for updates</h2>
          <SocialLinks />
        </div>
      </div>
    </main>
  )
}

